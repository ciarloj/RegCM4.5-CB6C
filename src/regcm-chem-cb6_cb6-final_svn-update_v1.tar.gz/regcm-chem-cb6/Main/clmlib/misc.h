#ifndef MISC_SET
#define MISC_SET
#undef COUP_CSM
#undef COUP_CSM
#endif
