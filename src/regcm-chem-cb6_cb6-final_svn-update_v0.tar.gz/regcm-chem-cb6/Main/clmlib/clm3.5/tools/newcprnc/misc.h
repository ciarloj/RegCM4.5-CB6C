#ifndef MISC_SET
#define MISC_SET
#endif

